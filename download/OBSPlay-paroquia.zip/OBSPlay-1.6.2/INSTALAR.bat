@echo off
title Instalador do OBSPlay
net session >nul 2>&1
if errorlevel 1 (
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
tasklist /fi "imagename eq obs64.exe" | find /i "obs64.exe" >nul
if not errorlevel 1 (
  echo.
  echo O OBS esta aberto. Feche o OBS e rode este instalador de novo.
  echo.
  pause
  exit /b
)
if not exist "%ProgramFiles%\obs-studio\bin\64bit\obs64.exe" (
  echo.
  echo O OBS Studio nao foi encontrado. Instale o OBS Studio primeiro: https://obsproject.com
  echo.
  pause
  exit /b
)
xcopy "%~dp0obsplay" "%ProgramData%\obs-studio\plugins\obsplay\" /E /I /Y /Q >nul
if errorlevel 1 (
  echo.
  echo Nao foi possivel copiar o plugin.
  pause
  exit /b
)
echo.
echo OBSPlay instalado com sucesso.
echo Abra o OBS: a janela do OBSPlay mostra o CODIGO DO COMPUTADOR.
echo Envie esse codigo ao responsavel para receber a chave da paroquia.
echo.
pause
